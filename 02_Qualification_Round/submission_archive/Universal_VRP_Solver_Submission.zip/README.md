# Universal VRP Solver — Technical Code Documentation

Project: AI Hackathon Route Optimization 2026
Source File: Universal_VRP_Solver.py
Core Engine: Google OR-Tools Routing Library (Constraint Programming + Metaheuristics)

==============================================================================
1. TECHNICAL ARCHITECTURE & DESIGN PRINCIPLES
==============================================================================

Universal_VRP_Solver.py ถูกออกแบบด้วยสถาปัตยกรรม Modular Single-File Engine 
มีความกระชับ (Zero Boilerplate) โดยใช้ Dependency หลักเพียง 2 ตัวคือ ortools และ numpy 
เพื่อให้สามารถพกพา (Portable) และนำไปติดตั้งบนสภาพแวดล้อม Production หรือ Docker ได้ทันที

[Unified Dual-Mode Architecture]
- Standard CVRP Mode (Default): ทำงานอัตโนมัติเมื่อรับเฉพาะไฟล์ .vrp โดยจะปิดมิติเวลา 
  และใช้ First Solution เป็น PATH_CHEAPEST_ARC เพื่อเน้นความเร็วสูงสุดในการหาระยะทางที่สั้นที่สุด
- Real-world VRPTW Mode: ทำงานอัตโนมัติเมื่อตรวจพบ Flag --config <path.json> 
  โดยระบบจะ Dynamic Load ข้อมูลขนาดกองรถ (Heterogeneous Fleet), อัตราคิดต้นทุน (Cost Multiplier), 
  และกรอบเวลาส่งมอบ (Time Windows) เข้าสู่อาร์เรย์ของโมเดลทันที


==============================================================================
2. CODE STRUCTURE & MODULE BREAKDOWN
==============================================================================

โค้ดภายใน Universal_VRP_Solver.py แบ่งการทำงานออกเป็น 5 Layers อย่างเป็นสัดส่วน:

┌─────────────────────────────────────────────────────────────┐
│ 1. Data Ingestion Layer                                     │
│    - parse_vrp_file()       : TSPLIB format parsing (.vrp)  │
│    - load_advanced_config() : JSON constraints loader       │
├─────────────────────────────────────────────────────────────┤
│ 2. Spatial Matrix Engine                                    │
│    - compute_euclidean_matrix() : 2D Coordinate to Matrix   │
├─────────────────────────────────────────────────────────────┤
│ 3. OR-Tools Routing Model Builder                           │
│    - RoutingIndexManager    : Node index <-> OR-Tools index │
│    - RoutingModel           : Decision variables & Transit  │
│    - AddDimension()         : Capacity & Time Windows       │
├─────────────────────────────────────────────────────────────┤
│ 4. Search & Optimization Engine                             │
│    - FirstSolutionStrategy  : Greedy insertion heuristic    │
│    - LocalSearchMetaheuristic: Guided Local Search (GLS)    │
│    - TimeLimit & Solver     : 10s Time Budget Guard         │
├─────────────────────────────────────────────────────────────┤
│ 5. Extraction & Evaluation Layer                            │
│    - extract_solution()     : Assignment parsing to dict    │
│    - format_console_output(): Terminal ANSI report render   │
│    - calculate_gap()        : TSPLIB ground-truth evaluation│
└─────────────────────────────────────────────────────────────┘

รายละเอียดฟังก์ชันสำคัญในโค้ด:

1. parse_vrp_file(file_path)
   - อ่าน Header: DIMENSION, CAPACITY, EDGE_WEIGHT_TYPE
   - สกัดพิกัด NODE_COORD_SECTION และความต้องการสินค้า DEMAND_SECTION
   - แปลง Index โหนดจากระบบ 1-based ของ TSPLIB เข้าสู่ระบบ Array Index อย่างแม่นยำ

2. load_advanced_config(config_path, total_nodes, default_capacity)
   - อ่านข้อมูลกองรถที่มีขนาดต่างกัน (fleet array)
   - แมปกรอบเวลาของลูกค้าแต่ละราย (time_windows object) ระบุ Ready Time / Due Time / Service Time

3. compute_distance_matrix(coordinates)
   - คำนวณ Euclidean Distance Matrix ขนาด N x N:
     d(i, j) = round( sqrt( (x_i - x_j)^2 + (y_i - y_j)^2 ) )

4. solve_vrp(...)
   - ฟังก์ชันหลักที่ประกอบ RoutingIndexManager และ RoutingModel
   - ลงทะเบียน Transit Callback, Capacity Dimension, และ Time Dimension
   - สั่งรัน Solver ด้วย routing.SolveWithParameters(search_params)


==============================================================================
3. MATHEMATICAL FORMULATION & OR-TOOLS API MAPPING
==============================================================================

ตารางจับคู่ระหว่างสมการคณิตศาสตร์ของปัญหา VRP เข้ากับฟังก์ชัน Google OR-Tools API ในโค้ด:

- Objective Function:
  min sum_{k=1..K} c_k * sum_{(i,j) in R_k} d_{ij}
  -> routing.SetArcCostEvaluatorOfVehicle(eval_idx, vehicle_id)

- Capacity Constraint:
  sum_{i in R_k} q_i <= Q_k (forall k)
  -> routing.AddDimensionWithVehicleCapacity(demand_eval_idx, 0, capacities, True, 'Capacity')

- Time Windows:
  ready_i <= t_i <= due_i (forall i)
  -> time_dim.CumulVar(node_idx).SetRange(ready_time, due_time)

- Depot Boundary:
  t_depot in [0, Max_Horizon]
  -> time_dim.CumulVar(routing.End(k)).SetRange(0, horizon)

- First Solution:
  Greedy Initial Routing
  -> search_parameters.first_solution_strategy = FirstSolutionStrategy.PATH_CHEAPEST_ARC

- Metaheuristic:
  Local Optima Escape (Penalty)
  -> search_parameters.local_search_metaheuristic = LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH


==============================================================================
4. ROBUSTNESS & EDGE-CASE HANDLING
==============================================================================

1. Missing Time Windows Fallback:
   หากไฟล์ Config ไม่ได้ระบุ Time Window ของโหนดใด โค้ดจะกำหนดค่า Default ให้เป็น [0, Max_Horizon] 
   ป้องกันไม่ให้โมเดลเกิดปัญหา Infeasible จากข้อมูลลูกค้าที่ไม่สมบูรณ์

2. Dynamic Fleet Balancing:
   กรณีจำนวนรถที่ให้มามีมากกว่าจำนวนที่ต้องใช้จริง Solver จะจัดสรรเฉพาะรถที่คุ้มค่าที่สุด 
   (Vehicles Utilized <= Available Fleet) โดยไม่บังคับให้รถทุกคันต้องวิ่งเปล่า

3. Deterministic Time Guard:
   กำหนด search_parameters.time_limit.seconds ไว้อย่างชัดเจน รับประกันว่าโปรแกรมจะไม่มีวันค้าง 
   หรือรันเกินงบเวลาที่กำหนด

4. Flexible Regex Tokenizer:
   Parser ใช้ Regular Expression ในการตัดช่องว่าง (Whitespace / Tabs / CRLF / LF) 
   ทำให้สามารถอ่านไฟล์ .vrp ที่สร้างจากต่าง OS ได้อย่างราบรื่น


==============================================================================
5. PRODUCTION READINESS & EXTENSION GUIDE
==============================================================================

- Real-Road Routing API: สามารถแทนที่ฟังก์ชัน compute_distance_matrix() ด้วยการเรียก 
  OSRM หรือ Google Distance Matrix API ได้ทันทีโดยไม่ต้องแก้โครงสร้างโมเดล
- Dynamic Cost Matrix: รองรับการปรับ Cost Multiplier ตามประเภทรถ ราคาน้ำมัน หรือค่าแรงคนขับ


==============================================================================
6. CLI REFERENCE & EXECUTION GUIDE (วิธีรันโค้ด)
==============================================================================

[การติดตั้งไลบรารี]
pip install ortools numpy

[พารามิเตอร์ของคำสั่ง]
usage: Universal_VRP_Solver.py [-h] [--config CONFIG] [--time_limit TIME_LIMIT] [--no_eval] vrp_file

positional arguments:
  vrp_file              Path to TSPLIB .vrp problem file

optional arguments:
  --config CONFIG       Path to optional .json configuration file (fleet & time windows)
  --time_limit LIMIT    Solver time budget in seconds (Default: 10)
  --no_eval             Disable TSPLIB optimality gap evaluation

------------------------------------------------------------------------------
ตัวอย่างคำสั่งรันใน Terminal:
------------------------------------------------------------------------------

1. โหมด Standard Benchmark (CVRP)
   # ทดสอบชุดข้อมูล A-n32-k5 (Optimal: 784)
   python Universal_VRP_Solver.py A-n32-k5.vrp

   # ทดสอบชุดข้อมูล B-n31-k5 (Optimal: 672)
   python Universal_VRP_Solver.py B-n31-k5.vrp

   # ทดสอบชุดข้อมูล P-n40-k5 (Optimal: 458)
   python Universal_VRP_Solver.py P-n40-k5.vrp

2. โหมด Real-world Logistics (VRPTW + Heterogeneous Fleet)
   # ทดสอบชุดข้อมูลโจทย์จริง FM01
   python Universal_VRP_Solver.py FM01-n29-k6.vrp --config FM01-optional.json

3. ปรับแต่งพารามิเตอร์เวลาค้นหา
   # กำหนด Time Limit เป็น 15 วินาที
   python Universal_VRP_Solver.py A-n32-k5.vrp --time_limit 15
